import bentoml
import pandas as pd

from typing import Literal
from pydantic import BaseModel, Field, ConfigDict

YesNo = Literal["Yes", "No"]

class PatientInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    age: float = Field(ge=1, le=120)
    gender: Literal["Male", "Female"]
    polyuria: YesNo
    polydipsia: YesNo
    sudden_weight_loss: YesNo
    weakness: YesNo
    polyphagia: YesNo
    genital_thrush: YesNo
    visual_blurring: YesNo
    itching: YesNo
    irritability: YesNo
    delayed_healing: YesNo
    partial_paresis: YesNo
    muscle_stiffness: YesNo
    alopecia: YesNo
    obesity: YesNo


@bentoml.service
class DiabetesClassifier:

    model_ref = bentoml.models.BentoModel(
        "diabetes_risk_educational:5kx4n5xeu6anqasc"
    )

    def __init__(self):
        self.model = bentoml.mlflow.load_model(
            self.model_ref
        )

    @bentoml.api
    def predict(self, input_data: PatientInput) -> dict:

        # Convert validated request into model input
        record = input_data.model_dump()
        frame = pd.DataFrame([record])

        # Ensure expected numeric type
        frame["age"] = frame["age"].astype("float64")

        prediction = int(
            self.model.predict(frame)[0]
        )

        return {
            "prediction": prediction,
            "label": (
                "Positive" if prediction == 1
                else "Negative"
            ),
            "model": "RandomForest-Educational"
        }
