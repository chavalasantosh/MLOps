# Diabetes Prediction — BentoML Docker Lab

This project is an **educational**, non-clinical demonstration. Do not use it for medical decisions, and do not expose it publicly.

Files were exported from Google Colab (Python 3.13.18). This kit adds a Dockerfile and `.dockerignore` to the user's existing files. The serialized model must only be loaded from sources you trust.

## Safety / space check first

On the target Ubuntu host, run `df -h /` and `docker system df` before any build. Heavy dependencies (MLflow, BentoML, numerical libraries) may consume multiple GB of disk and memory while building. The host previously showed only 5.2 GB free; do **not** build on it without adequate additional free space or a separate build machine. Do not prune all Docker images/volumes; other applications are running.

## Build (once you have enough free space)

```sh
docker build -t diabetes-bentoml:v1 .
```

## Start locally on the host

```sh
docker run --rm -d --name diabetes-bentoml-lab \
  --memory=2g -p 127.0.0.1:3000:3000 diabetes-bentoml:v1
docker logs --tail=50 diabetes-bentoml-lab
curl -fsS http://127.0.0.1:3000/readyz
curl -sS -X POST http://127.0.0.1:3000/predict \
  -H 'Content-Type: application/json' \
  --data-binary @test_request.json
```

If port 3000 is already in use, change the **left** side of `127.0.0.1:3000:3000` (e.g. 3001:3000), and call port 3001 in curl.

## Stop your test

```sh
docker stop diabetes-bentoml-lab
```

These commands target only the new educational container, not existing unrelated containers.
